function doGet(e) {
  const page = String(e && e.parameter && e.parameter.page || 'parent');
  const t = HtmlService.createTemplateFromFile('화면');
  // 경로는 화면 선택일 뿐 인증 수단이 아닙니다.
  t.page = ['parent','admin','teacher'].includes(page) ? page : 'parent';
  t.entry = e && e.parameter && e.parameter.entry === '1' ? '1' : '0';
  return t.evaluate().setTitle('학교 파일 제출').addMetaTag('viewport','width=device-width, initial-scale=1');
}

/** 공개 진입점은 하나로 제한하며 보호 작업은 각 처리 함수에서도 인증합니다. */
function 요청(action, data) {
  try {
    const handlers = {
      시작:시작_, 로그인확인:로그인확인_, 학생확인:학생확인_, 제출시작:제출시작_, 파일전송:파일전송_, 제출완료:제출완료_, 제출상태:제출상태_, 제출조회:제출조회_,
      교사신청:교사신청_, 관리자자료:관리자자료_, 저장:저장_, 학생삭제:학생삭제_, CSV확인:CSV확인_, CSV반영:CSV반영_,
      학급생성:학급생성_, 승인:승인_, 권한저장:권한저장_, 담임저장:담임저장_, 담임삭제:담임삭제_,
      제출함삭제:제출함삭제_, 제출함복원:제출함복원_, 파일목록:파일목록_, 파일작업:파일작업_, 다운로드:다운로드_, 압축:압축_, 설정저장:설정저장_, 대시보드:대시보드_
    };
    if (!Object.prototype.hasOwnProperty.call(handlers, action)) throw new Error('지원하지 않는 요청입니다.');
    return {ok:true,data:handlers[action](data || {})};
  } catch(e) {
    // 입력값·암호·파일 본문은 로그에 남기지 않습니다.
    return {ok:false,message:String(e.message || '요청을 처리하지 못했습니다.').slice(0,250)};
  }
}
function 시작_() {
  const p = 설정_(), cache = CacheService.getScriptCache();
  let raw = cache.get('public-config'), config;
  if (raw) config = JSON.parse(raw);
  else {
    config = {year:현재학년도_(),classes:목록_('학급').filter(x => 불리언_(x.active) && Number(x.year) === 현재학년도_()).map(x => ({grade:Number(x.grade),classNo:Number(x.classNo)})),
      limits:{fileMB:Number(p.FILE_MB),totalMB:Number(p.TOTAL_MB),count:Number(p.FILE_COUNT)}};
    cache.put('public-config',JSON.stringify(config),120);
  }
  return Object.assign({},config,{staffUrl:p.STAFF_URL,publicUrl:p.PUBLIC_URL});
}
function 로그인확인_() {
  const u = 사용자_();
  if (!['teacher','admin'].includes(u.role)) return {user:u,year:현재학년도_(),boxes:[]};
  const permitted = u.role === 'admin' ? null : 목록_('권한').filter(a => a.teacherId === u.id && 불리언_(a.view));
  return {user:u,year:현재학년도_(),boxes:목록_('제출함').filter(b => b.folderId && (u.role === 'admin' || (!b.deleteAt && permitted.some(a => a.boxId === b.id)))).map(b => ({id:b.id,year:b.year,name:b.name,active:불리언_(b.active),deleted:!!b.deleteAt}))};
}
function 학생입력_(d) {
  const o = {year:현재학년도_(),grade:숫자_(d.grade,1,12),classNo:숫자_(d.classNo,1,99),student:정리_(d.student,60),number:정리_(d.number,10)};
  if (!o.student) throw new Error('학생 이름을 입력하세요.');
  const classes = 목록_('학급').filter(c => Number(c.year)===o.year && 불리언_(c.active));
  if (!classes.some(c => Number(c.grade)===o.grade && Number(c.classNo)===o.classNo)) throw new Error('등록된 학년과 반을 선택하세요.');
  const students = 목록_('학생').filter(s => Number(s.year)===o.year && 불리언_(s.active));
  const valid = new Map(); students.forEach(s => valid.set([s.grade,s.classNo,s.number,s.name].join('|'),s));
  const all = [...valid.values()], cls = all.filter(s => Number(s.grade)===o.grade && Number(s.classNo)===o.classNo);
  const must = all.length >= 70 || cls.length >= 15;
  let matches = cls.filter(s => s.name === o.student);
  if (matches.length>1 && !o.number) return Object.assign(o,{needsNumber:true});
  if (o.number) matches = matches.filter(s => String(s.number) === String(Number(o.number)));
  if (must && matches.length!==1) throw new Error('학생 정보가 일치하지 않습니다. 학년, 반, 이름을 확인해 주세요.');
  o.studentId = matches.length===1 ? matches[0].id : '';
  o.studentKey = o.studentId || [o.year,o.grade,o.classNo,o.student,o.number].join('|');
  return o;
}
function 학생확인_(d) {
  const s = 학생입력_(d); if (s.needsNumber) return {needsNumber:true};
  return {needsNumber:false,boxes:학부모제출함_(s)};
}
function 접수가능_(b) {
  const now = Date.now();
  return !!b.folderId && 불리언_(b.active) && !b.deleteAt && (!b.openAt || Date.parse(b.openAt)<=now) && (!b.closeAt || Date.parse(b.closeAt)>=now);
}
function 학부모제출함_(s) {
  const cutoff = Date.now()-30*86400000;
  const stats = 목록_('접수').filter(r => Number(r.year)===s.year && ['complete','partial'].includes(r.status) && Date.parse(r.createdAt)>=cutoff);
  const counts = {}; stats.forEach(r => counts[r.boxId]=(counts[r.boxId]||0)+1);
  const boxes = 목록_('제출함').filter(b => Number(b.year)===s.year && 접수가능_(b));
  const general = boxes.filter(b=>b.type==='general').sort((a,b)=>(counts[b.id]||0)-(counts[a.id]||0)||Number(a.sort)-Number(b.sort)||a.name.localeCompare(b.name,'ko'));
  const popular = general.slice(0,3).map(b=>b.id);
  return general.concat(boxes.filter(b=>b.type==='class' && Number(b.grade)===s.grade && Number(b.classNo)===s.classNo)).map(b=>({id:b.id,name:b.name,type:b.type,popular:popular.includes(b.id)}));
}
function 암호검사_(p) {
  if (typeof p!=='string' || p.length<10 || p.length>100 || !/[A-Za-z가-힣]/.test(p) || !/[0-9]/.test(p)) throw new Error('임시암호는 문자와 숫자를 섞어 10~100자로 입력하세요.');
}
function 접수토큰_(r) { return 서명_('receipt|' + r.id + '|' + r.requestId); }
function 접수인증_(d) {
  const r = 목록_('접수').find(r=>r.id===d.receiptId);
  if (!r || !동일_(접수토큰_(r),d.token || '')) throw new Error('접수 정보를 다시 확인하세요.');
  return r;
}
function 제출시작_(d) {
  암호검사_(d.password);
  const s = 학생입력_(d); if(s.needsNumber) throw new Error('동명이인 구분을 위해 학생 번호를 입력하세요.');
  const parent = 정리_(d.parent,60), phone = 정리_(d.phone,30).replace(/[^0-9]/g,'');
  if(!parent || !/^0[0-9]{8,10}$/.test(phone)) throw new Error('학부모 이름과 전화번호를 확인하세요.');
  const box = 학부모제출함_(s).find(b=>b.id===d.boxId);
  if(!box) throw new Error('선택한 제출함에는 제출할 수 없습니다.');
  const requestId = 정리_(d.requestId,80); if (!/^[a-zA-Z0-9-]{16,80}$/.test(requestId)) throw new Error('요청 식별자가 올바르지 않습니다.');
  return 잠금_(()=>{
    const old = 목록_('접수').find(r=>r.requestId===requestId);
    if(old) {
      if (!동일_(old.proof,서명_(old.salt+'|'+d.password)) || old.student!==s.student || Number(old.grade)!==s.grade || Number(old.classNo)!==s.classNo || old.boxId!==d.boxId || old.parent!==parent || old.phone!==phone) throw new Error('기존 접수 정보와 다릅니다. 새 접수를 시작하세요.');
      return {receiptId:old.id,token:접수토큰_(old)};
    }
    const key = 'rate:' + 서명_(s.studentKey).slice(0,35), cache = CacheService.getScriptCache();
    if (Number(cache.get(key)||0)>=10) throw new Error('잠시 후 다시 제출해 주세요.');
    cache.put(key,String(Number(cache.get(key)||0)+1),3600);
    const salt = 아이디_(), now = 시각_();
    const r = {id:아이디_(),requestId:requestId,year:s.year,grade:s.grade,classNo:s.classNo,studentId:s.studentId,student:s.student,parent:parent,phone:phone,salt:salt,proof:서명_(salt+'|'+d.password),boxId:d.boxId,status:'uploading',createdAt:now,updatedAt:now};
    추가_('접수',r); return {receiptId:r.id,token:접수토큰_(r)};
  });
}
function 학생폴더_(r,b) {
  const key = r.studentId || [r.year,r.grade,r.classNo,r.student].join('|');
  const old = 목록_('학생폴더').find(x=>x.boxId===b.id && x.studentKey===key);
  if(old) return DriveApp.getFolderById(old.folderId);
  const suffix = r.studentId ? '_' + r.studentId.slice(0,6) : '';
  const folder = DriveApp.getFolderById(b.folderId).createFolder(안전파일명_(r.grade+'_'+r.classNo+'_'+r.student+suffix));
  추가_('학생폴더',{id:아이디_(),boxId:b.id,studentKey:key,folderId:folder.getId()}); return folder;
}
function 안전파일명_(name) { return 정리_(name,160).replace(/[\\/:*?"<>|\u0000-\u001f]/g,'_').replace(/^\.+/,'_') || '첨부파일'; }
function 파일전송_(d) {
  const p=설정_(), r=접수인증_(d), name=안전파일명_(d.name), ext=name.split('.').pop().toLowerCase();
  const types={hwp:['application/x-hwp','application/haansofthwp','application/vnd.hancom.hwp'],hwpx:['application/hwp+zip','application/vnd.hancom.hwpx','application/zip'],xls:['application/vnd.ms-excel'],xlsx:['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','application/zip'],pdf:['application/pdf'],jpg:['image/jpeg'],jpeg:['image/jpeg'],png:['image/png'],gif:['image/gif'],webp:['image/webp'],bmp:['image/bmp','image/x-ms-bmp'],heic:['image/heic','image/heif'],heif:['image/heif','image/heic']};
  if(!types[ext]) throw new Error('허용하지 않는 확장자입니다. HWP, HWPX, 엑셀, PDF, 이미지 파일을 선택하세요.');
  const mime=정리_(d.mime,120)||'application/octet-stream';
  if (mime!=='application/octet-stream' && !types[ext].includes(mime)) throw new Error('확장자와 파일 형식 정보가 다릅니다.');
  const clientId=정리_(d.clientId,150); if(!clientId) throw new Error('파일 식별자가 없습니다.');
  if(typeof d.base64!=='string' || d.base64.length>Number(p.FILE_MB)*1048576*1.34+16) throw new Error('파일 용량 제한을 초과했습니다.');
  const bytes=Utilities.base64Decode(d.base64);
  if(!bytes.length || bytes.length>Number(p.FILE_MB)*1048576) throw new Error('파일 용량을 확인하세요.');
  // MIME은 클라이언트 값이므로 널리 알려진 형식은 시그니처도 확인합니다.
  const sig=bytes.slice(0,12).map(x=>((x+256)%256).toString(16).padStart(2,'0')).join('');
  if ((ext==='pdf'&&!sig.startsWith('25504446')) || (ext==='png'&&!sig.startsWith('89504e470d0a1a0a')) || (['jpg','jpeg'].includes(ext)&&!sig.startsWith('ffd8')) || (['xlsx','hwpx'].includes(ext)&&!sig.startsWith('504b'))) throw new Error('파일 내용과 확장자가 일치하지 않습니다.');
  // 소규모 파일의 저장과 메타데이터 확정만 잠급니다. 인코딩·전송은 잠금 밖입니다.
  return 잠금_(()=>{
    const current=접수인증_(d), b=목록_('제출함').find(b=>b.id===current.boxId);
    if(!b || !접수가능_(b)) throw new Error('현재 접수할 수 없는 제출함입니다.');
    if (Date.now()-Date.parse(current.createdAt)>86400000) throw new Error('접수 유효시간이 지났습니다. 새 접수를 시작하세요.');
    const saved=목록_('파일').filter(f=>f.receiptId===r.id && f.status==='stored');
    const duplicate=saved.find(f=>f.clientId===clientId); if(duplicate) return {id:duplicate.id,name:duplicate.name,duplicate:true};
    if(saved.length>=Number(p.FILE_COUNT) || saved.reduce((a,f)=>a+Number(f.size),0)+bytes.length>Number(p.TOTAL_MB)*1048576) throw new Error('접수별 파일 수 또는 총용량 제한을 초과했습니다.');
    const folder=학생폴더_(current,b), stem=name.slice(0,-ext.length-1);
    let finalName=stem+'['+Utilities.formatDate(new Date(),'Asia/Seoul','yy-MM-dd-HH-mm-ss')+'].'+ext;
    let n=1; while(folder.getFilesByName(finalName).hasNext()) finalName=stem+'['+Utilities.formatDate(new Date(),'Asia/Seoul','yy-MM-dd-HH-mm-ss')+']_'+(n++)+'.'+ext;
    const id=아이디_();
    추가_('파일',{id:id,receiptId:r.id,clientId:clientId,boxId:b.id,originalName:name,name:finalName,size:bytes.length,mime:mime,driveId:'',status:'saving',createdAt:시각_()});
    let file;
    try {
      file=folder.createFile(Utilities.newBlob(bytes,mime,finalName));
      수정_('파일',id,{driveId:file.getId(),status:'stored'});
      수정_('접수',r.id,{status:'uploading',updatedAt:시각_()});
      return {id:id,name:finalName};
    } catch(e) {
      if(file) { try{file.setTrashed(true);}catch(ignore){} }
      수정_('파일',id,{status:'failed'}); throw new Error('저장에 실패했습니다. 해당 파일을 다시 전송하세요.');
    }
  });
}
function 제출완료_(d) {
  return 잠금_(()=>{
    const r=접수인증_(d), count=목록_('파일').filter(f=>f.receiptId===r.id&&f.status==='stored').length;
    const expected=숫자_(d.expected,1,Number(설정_().FILE_COUNT));
    const status=count>=expected?'complete':count?'partial':'failed';
    수정_('접수',r.id,{status:status,updatedAt:시각_()});
    return {id:r.id,status:status,count:count};
  });
}
function 제출상태_(d) {
  const r=접수인증_(d); return {id:r.id,status:r.status,files:목록_('파일').filter(f=>f.receiptId===r.id&&f.status==='stored').map(f=>({id:f.id,clientId:f.clientId,name:f.name,size:f.size}))};
}
function 제출조회_(d) {
  const y=숫자_(d.year,2020,2100), g=숫자_(d.grade,1,12), c=숫자_(d.classNo,1,99), name=정리_(d.student,60);
  암호검사_(d.password);
  const key='lookup:'+서명_([y,g,c,name].join('|')).slice(0,40), cache=CacheService.getScriptCache();
  const hits=잠금_(()=>{const n=Number(cache.get(key)||0)+1;cache.put(key,String(n),600);return n;});
  if(hits>8) throw new Error('조회 시도가 많습니다. 10분 후 다시 시도하세요.');
  const receipts=목록_('접수').filter(r=>Number(r.year)===y&&Number(r.grade)===g&&Number(r.classNo)===c&&r.student===name&&동일_(r.proof,서명_(r.salt+'|'+d.password)));
  if(!receipts.length) throw new Error('입력 정보와 일치하는 제출 기록을 확인할 수 없습니다.');
  const fs=목록_('파일'), boxes=목록_('제출함');
  return receipts.map(r=>({id:r.id,createdAt:r.createdAt,status:r.status,box:(boxes.find(b=>b.id===r.boxId)||{}).name||'이전 제출함',files:fs.filter(f=>f.receiptId===r.id&&f.status==='stored').map(f=>({name:f.name,size:f.size}))}));
}
function 교사신청_(d) {
  const u=사용자_(); if(!u.email) throw new Error('학교 Google 계정으로 로그인하세요.');
  if(['admin','teacher'].includes(u.role)) throw new Error('이미 승인된 계정입니다.');
  if(['suspended','deleted'].includes(u.status)) throw new Error('이용 중지 계정입니다. 관리자에게 문의하세요.');
  const name=정리_(d.name,60); if(!name) throw new Error('이름을 입력하세요.');
  if(학교메일_(d.email)!==u.email) throw new Error('로그인한 학교 이메일과 일치해야 합니다.');
  const home=불리언_(d.homeroom), y=숫자_(d.year,2020,2100);
  const g=home?숫자_(d.grade,1,12):'', c=home?숫자_(d.classNo,1,99):'';
  return 잠금_(()=>{
    if(목록_('인증신청').some(r=>r.email===u.email&&r.status==='pending')) throw new Error('이미 승인 대기 중입니다.');
    추가_('인증신청',{id:아이디_(),email:u.email,name:name,year:y,grade:g,classNo:c,homeroom:home,status:'pending',createdAt:시각_()});
    return {message:'신청했습니다. 관리자 승인을 기다려 주세요.'};
  });
}
