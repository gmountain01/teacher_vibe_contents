function 관리자자료_(d) {
  관리자_(); const y=숫자_(d.year||현재학년도_(),2020,2100), p=설정_();
  return {year:y,classes:목록_('학급').filter(x=>Number(x.year)===y),students:목록_('학생').filter(x=>Number(x.year)===y&&불리언_(x.active)),teachers:목록_('교사'),applications:목록_('인증신청').filter(x=>x.status==='pending'),homerooms:목록_('담임').filter(x=>Number(x.year)===y),boxes:목록_('제출함').filter(x=>Number(x.year)===y),permissions:목록_('권한'),settings:{PUBLIC_URL:p.PUBLIC_URL,STAFF_URL:p.STAFF_URL,FILE_MB:p.FILE_MB,TOTAL_MB:p.TOTAL_MB,FILE_COUNT:p.FILE_COUNT,ZIP_MB:p.ZIP_MB,ZIP_COUNT:p.ZIP_COUNT,RETENTION_DAYS:p.RETENTION_DAYS},audit:목록_('감사').slice(-30).reverse()};
}
function 설정저장_(d) {
  관리자_(); return 잠금_(()=>{
    const values={};
    ['PUBLIC_URL','STAFF_URL'].forEach(k=>{const v=정리_(d[k],500); if(v&&!/^https:\/\/script\.google\.com\/macros\/s\/[A-Za-z0-9_-]+\/exec$/.test(v)) throw new Error('배포의 /exec 주소를 입력하세요.'); values[k]=v;});
    ['FILE_MB','TOTAL_MB','FILE_COUNT','ZIP_MB','ZIP_COUNT','RETENTION_DAYS'].forEach(k=>values[k]=String(숫자_(d[k],1,k==='RETENTION_DAYS'?3650:k.includes('COUNT')?50:30)));
    if(Number(values.FILE_MB)>Number(values.TOTAL_MB)) throw new Error('전체 용량이 파일별 용량 이상이어야 합니다.');
    PropertiesService.getScriptProperties().setProperties(values); 캐시삭제_(); 감사_('설정 변경','운영 설정'); return {message:'저장했습니다.'};
  });
}
function 학년도폴더_(y) {
  const root=DriveApp.getFolderById(설정_().ROOT_ID), name=y+'학년도', found=root.getFoldersByName(name);
  return found.hasNext()?found.next():root.createFolder(name);
}
function 제출함추가_(o) {
  const id=아이디_(), folder=학년도폴더_(o.year).createFolder(안전파일명_(o.name)+'_'+id.slice(0,6));
  const b=Object.assign({id:id,type:'general',grade:'',classNo:'',active:true,sort:0,openAt:'',closeAt:'',deleteAt:'',folderId:folder.getId()},o);
  추가_('제출함',b); return b;
}
function 저장_(d) {
  관리자_(); return 잠금_(()=>{
    const o=d.item||{}, kind=d.kind;
    if(kind==='student') {
      const s=학생정규화_(o), all=목록_('학생');
      if(all.some(x=>x.id!==o.id&&불리언_(x.active)&&Number(x.year)===s.year&&Number(x.grade)===s.grade&&Number(x.classNo)===s.classNo&&String(x.number)===String(s.number))) throw new Error('같은 반에 같은 번호가 있습니다.');
      if(o.id) 수정_('학생',o.id,s); else 추가_('학생',Object.assign({id:아이디_()},s));
    } else if(kind==='teacher') {
      const name=정리_(o.name,60), email=학교메일_(o.email); if(!name) throw new Error('교사 이름을 입력하세요.');
      const teachers=목록_('교사'); if(teachers.some(t=>t.id!==o.id&&t.email===email)) throw new Error('이미 등록된 이메일입니다.');
      const status=['suspended','deleted'].includes(o.status)?o.status:'approved';
      const record={name:name,email:email,status:status};
      if(o.id) 수정_('교사',o.id,record); else 추가_('교사',Object.assign({id:아이디_(),createdAt:시각_()},record));
    } else if(kind==='box') {
      const name=정리_(o.name,100); if(!name) throw new Error('제출함 이름을 입력하세요.');
      const openAt=o.openAt?new Date(o.openAt).toISOString():'', closeAt=o.closeAt?new Date(o.closeAt).toISOString():'';
      if(openAt&&closeAt&&openAt>closeAt) throw new Error('접수 기간을 확인하세요.');
      const record={name:name,active:불리언_(o.active),sort:숫자_(o.sort||0,0,999),openAt:openAt,closeAt:closeAt};
      if(o.id) { const b=목록_('제출함').find(b=>b.id===o.id); if(!b||!b.folderId||b.deleteAt) throw new Error('수정할 수 없는 제출함입니다.'); 수정_('제출함',o.id,record); }
      else 제출함추가_(Object.assign({year:숫자_(o.year,2020,2100)},record));
    } else throw new Error('지원하지 않는 저장입니다.');
    감사_('자료 저장',kind+':'+(o.id||'신규')); 캐시삭제_(); return {message:'저장했습니다.'};
  });
}
function 학생정규화_(s) {
  const o={year:숫자_(s.year,2020,2100),grade:숫자_(s.grade,1,12),classNo:숫자_(s.classNo,1,99),number:숫자_(s.number,1,999),name:정리_(s.name,60),active:true};
  if(!o.name) throw new Error('학생 이름을 입력하세요.');
  if(!목록_('학급').some(c=>Number(c.year)===o.year&&Number(c.grade)===o.grade&&Number(c.classNo)===o.classNo&&불리언_(c.active))) throw new Error('먼저 해당 학급을 생성하세요.');
  return o;
}
function 학생삭제_(d) {
  관리자_(); return 잠금_(()=>{수정_('학생',d.id,{active:false}); 감사_('학생 비활성화',d.id);return {message:'학생을 삭제했습니다. 과거 제출 기록은 보존됩니다.'};});
}
function CSV분석_(text) {
  const rows=Utilities.parseCsv(String(text||'').replace(/^\uFEFF/,''));
  if(rows.length>1001) throw new Error('한 번에 1,000명까지 등록할 수 있습니다.');
  const header=rows.shift()||[], wanted=['학년도','학년','반','번호','학생이름'];
  if(wanted.some((x,i)=>정리_(header[i])!==x)) throw new Error('양식의 열 제목과 순서를 유지하세요.');
  const errors=[], result=[], keys=new Set();
  rows.forEach((r,i)=>{
    if(r.every(x=>!정리_(x))) return;
    try {
      const o=학생정규화_({year:r[0],grade:r[1],classNo:r[2],number:r[3],name:r[4]});
      const key=[o.year,o.grade,o.classNo,o.number].join('|');
      if(keys.has(key)) throw new Error('CSV 내부 학급·번호 중복'); keys.add(key);result.push(o);
    } catch(e) { errors.push((i+2)+'행: '+e.message); }
  });
  return {rows:result,errors:errors};
}
function CSV확인_(d) {
  관리자_(); const p=CSV분석_(d.text), existing=목록_('학생').filter(s=>불리언_(s.active));
  let update=0; p.rows.forEach(o=>{if(existing.some(s=>['year','grade','classNo','number'].every(k=>Number(s[k])===Number(o[k]))))update++;});
  return {count:p.rows.length,updates:update,adds:p.rows.length-update,errors:p.errors,preview:p.rows.slice(0,20)};
}
function CSV반영_(d) {
  관리자_(); return 잠금_(()=>{
    const p=CSV분석_(d.text); if(p.errors.length||!p.rows.length) throw new Error('CSV 오류를 먼저 수정하세요.');
    const y=숫자_(d.year,2020,2100); if(p.rows.some(s=>s.year!==y)) throw new Error('현재 선택 학년도의 학생만 등록하세요.');
    const old=목록_('학생'), replacement=d.mode==='replace';
    if(replacement) {
      const backup=DriveApp.getFileById(설정_().DB_ID).makeCopy('명렬표 변경 전 백업_'+시각_(),DriveApp.getFolderById(설정_().ROOT_ID));
      감사_('전체 교체 전 백업',backup.getId());
    }
    const map=new Map(old.map(s=>[[s.year,s.grade,s.classNo,s.number].join('|'),s])), adds=[], output=old.map(s=>Object.assign({},s));
    const positions=new Map(output.map((s,i)=>[s.id,i]));
    if(replacement) output.forEach(s=>{if(Number(s.year)===y)s.active=false;});
    p.rows.forEach(o=>{const key=[o.year,o.grade,o.classNo,o.number].join('|'), match=map.get(key); if(match) Object.assign(output[positions.get(match.id)],o); else adds.push(Object.assign({id:아이디_()},o));});
    const sheet=표_('학생'), all=output.concat(adds);
    if(all.length) sheet.getRange(2,1,all.length,표구조.학생.length).setValues(all.map(o=>표구조.학생.map(k=>안전셀_(o[k]))));
    감사_('CSV 반영',String(p.rows.length)+'명 '+(replacement?'전체 교체':'추가·수정')); return {message:p.rows.length+'명 반영했습니다.'};
  });
}
function 학급생성_(d) {
  관리자_(); const year=숫자_(d.year,2020,2100), grade=숫자_(d.grade,1,12), start=숫자_(d.start,1,99), end=숫자_(d.end,1,99);
  if(start>end||end-start>39) throw new Error('반 범위는 한 번에 40개 이하로 지정하세요.');
  return 잠금_(()=>{
    const classes=목록_('학급'), boxes=목록_('제출함'); let count=0;
    for(let c=start;c<=end;c++) {
      const cls=classes.find(x=>Number(x.year)===year&&Number(x.grade)===grade&&Number(x.classNo)===c);
      if(!cls) 추가_('학급',{id:아이디_(),year:year,grade:grade,classNo:c,active:true});
      const b=boxes.find(x=>Number(x.year)===year&&x.type==='class'&&Number(x.grade)===grade&&Number(x.classNo)===c&&x.folderId);
      if(!b) { 제출함추가_({year:year,name:year+'학년도 '+grade+'학년 '+c+'반',type:'class',grade:grade,classNo:c}); count++; }
    }
    캐시삭제_(); 감사_('학급 생성',year+' '+grade+'학년 '+start+'~'+end+'반'); return {message:'새 제출함 '+count+'개를 생성했습니다.'};
  });
}
function 권한부여_(boxId,teacherId,values) {
  if(!목록_('제출함').some(b=>b.id===boxId)) throw new Error('제출함이 없습니다.');
  if(!목록_('교사').some(t=>t.id===teacherId&&t.status==='approved')) throw new Error('승인된 교사를 선택하세요.');
  const old=목록_('권한').find(a=>a.boxId===boxId&&a.teacherId===teacherId);
  const record={boxId:boxId,teacherId:teacherId,view:불리언_(values.view)||불리언_(values.download)||불리언_(values.manage),download:불리언_(values.download),manage:불리언_(values.manage)};
  if(old) 수정_('권한',old.id,record); else 추가_('권한',Object.assign({id:아이디_()},record));
}
function 권한저장_(d) {
  관리자_(); return 잠금_(()=>{권한부여_(d.boxId,d.teacherId,d); 감사_('제출함 권한 변경',d.boxId+':'+d.teacherId); return {message:'권한을 저장했습니다.'};});
}
function 담임배정_(d) {
  const year=숫자_(d.year,2020,2100), grade=숫자_(d.grade,1,12), cls=숫자_(d.classNo,1,99);
  const b=목록_('제출함').find(b=>Number(b.year)===year&&b.type==='class'&&Number(b.grade)===grade&&Number(b.classNo)===cls&&b.folderId&&!b.deleteAt);
  if(!b) throw new Error('먼저 해당 학급 제출함을 생성하세요.');
  const prev=목록_('담임').find(h=>Number(h.year)===year&&Number(h.grade)===grade&&Number(h.classNo)===cls);
  if(prev&&prev.teacherId!==d.teacherId) {
    const a=목록_('권한').find(a=>a.boxId===b.id&&a.teacherId===prev.teacherId); if(a) 제거_('권한',a.id);
  }
  const record={year:year,grade:grade,classNo:cls,teacherId:d.teacherId};
  권한부여_(b.id,d.teacherId,{view:true,download:true,manage:false});
  if(prev) 수정_('담임',prev.id,record); else 추가_('담임',Object.assign({id:아이디_()},record));
}
function 담임저장_(d) { 관리자_();return 잠금_(()=>{담임배정_(d);감사_('담임 변경',d.teacherId);return {message:'담임을 배정했습니다.'};}); }
function 담임삭제_(d) {
  관리자_();return 잠금_(()=>{
    const h=목록_('담임').find(h=>h.id===d.id); if(!h) throw new Error('배정 정보가 없습니다.');
    const b=목록_('제출함').find(b=>Number(b.year)===Number(h.year)&&b.type==='class'&&Number(b.grade)===Number(h.grade)&&Number(b.classNo)===Number(h.classNo));
    if(b) {const a=목록_('권한').find(a=>a.boxId===b.id&&a.teacherId===h.teacherId);if(a)제거_('권한',a.id);}
    제거_('담임',h.id);감사_('담임 해제',h.id);return {message:'배정과 해당 학급 권한을 해제했습니다. 제출자료는 보존됩니다.'};
  });
}
function 승인_(d) {
  관리자_();return 잠금_(()=>{
    const r=목록_('인증신청').find(r=>r.id===d.id&&r.status==='pending'); if(!r) throw new Error('처리할 대기 신청이 없습니다.');
    if(d.approve) {
      // 담임 제출함을 먼저 확인하여 부분 승인 오류를 줄입니다.
      if(불리언_(r.homeroom)&&!목록_('제출함').some(b=>Number(b.year)===Number(r.year)&&b.type==='class'&&Number(b.grade)===Number(r.grade)&&Number(b.classNo)===Number(r.classNo)&&b.folderId&&!b.deleteAt)) throw new Error('신청한 학급의 제출함을 먼저 생성하세요.');
      const t=목록_('교사').find(t=>t.email===r.email), id=t?t.id:아이디_();
      if(t) 수정_('교사',id,{name:r.name,status:'approved'}); else 추가_('교사',{id:id,email:r.email,name:r.name,status:'approved',createdAt:시각_()});
      if(불리언_(r.homeroom)) 담임배정_({year:r.year,grade:r.grade,classNo:r.classNo,teacherId:id});
    }
    수정_('인증신청',r.id,{status:d.approve?'approved':'rejected'});감사_(d.approve?'교사 승인':'교사 반려',r.id);return {message:'처리했습니다.'};
  });
}
function 제출함삭제_(d) {
  관리자_();return 잠금_(()=>{const b=제출함권한_(d.id);if(!b.folderId)throw new Error('이미 정리된 제출함입니다.');수정_('제출함',b.id,{active:false,deleteAt:new Date(Date.now()+30*86400000).toISOString()});캐시삭제_();감사_('제출함 삭제 예약',b.id);return {message:'30일 삭제 대기로 전환했습니다.'};});
}
function 제출함복원_(d) {
  관리자_();return 잠금_(()=>{const b=제출함권한_(d.id);if(!b.folderId)throw new Error('휴지통 이동 후에는 드라이브에서 복원하세요.');수정_('제출함',b.id,{active:true,deleteAt:''});캐시삭제_();감사_('제출함 복원',b.id);return {message:'복원했습니다.'};});
}
function 파일목록_(d) {
  제출함권한_(d.boxId,'view');const term=정리_(d.search,80).toLowerCase(), page=숫자_(d.page||1,1,100000), receipts=목록_('접수');
  const map=new Map(receipts.map(r=>[r.id,r]));
  let files=목록_('파일').filter(f=>f.boxId===d.boxId&&f.status==='stored').map(f=>{
    const r=map.get(f.receiptId)||{};
    return {id:f.id,name:f.name,originalName:f.originalName,size:f.size,createdAt:f.createdAt,student:r.student||'',grade:r.grade||'',classNo:r.classNo||'',parent:r.parent||'',receiptId:f.receiptId};
  }).filter(f=>!term||[f.name,f.student,f.parent,f.createdAt].join(' ').toLowerCase().includes(term)).reverse();
  return {total:files.length,page:page,files:files.slice((page-1)*30,page*30)};
}
function 파일권한_(id,kind) {
  const f=목록_('파일').find(f=>f.id===id&&f.status==='stored');if(!f) throw new Error('파일을 찾을 수 없습니다.');
  제출함권한_(f.boxId,kind);return f;
}
function 파일작업_(d) {
  교직원_();return 잠금_(()=>{
    const f=파일권한_(d.id,'manage'), file=DriveApp.getFileById(f.driveId);
    if(d.action==='rename') {
      const name=안전파일명_(d.name), oldExt=f.name.split('.').pop().toLowerCase();
      if(name.split('.').pop().toLowerCase()!==oldExt) throw new Error('확장자는 변경할 수 없습니다.');
      file.setName(name);수정_('파일',f.id,{name:name});
    } else if(d.action==='delete') {file.setTrashed(true);수정_('파일',f.id,{status:'trashed'});}
    else if(d.action==='move') {
      const target=제출함권한_(d.targetId,'manage'), r=목록_('접수').find(r=>r.id===f.receiptId);
      if(!target.folderId||target.deleteAt)throw new Error('이동할 수 없는 제출함입니다.');
      if(Number(target.year)!==Number(r.year))throw new Error('같은 학년도 제출함으로만 이동할 수 있습니다.');
      if(target.type==='class'&&(Number(target.grade)!==Number(r.grade)||Number(target.classNo)!==Number(r.classNo)))throw new Error('다른 반의 학급 제출함으로 이동할 수 없습니다.');
      file.moveTo(학생폴더_(r,target));수정_('파일',f.id,{boxId:target.id});
    } else throw new Error('지원하지 않는 파일 작업입니다.');
    감사_('파일 '+d.action,f.id+(d.targetId?':'+d.targetId:''));return {message:'처리했습니다.'};
  });
}
function 다운로드_(d) {
  const f=파일권한_(d.id,'download');if(Number(f.size)>Number(설정_().FILE_MB)*1048576)throw new Error('앱 다운로드 제한을 초과한 파일입니다. 관리자에게 문의하세요.');
  const blob=DriveApp.getFileById(f.driveId).getBlob();감사_('파일 다운로드',f.id);
  return {name:f.name,mime:f.mime,base64:Utilities.base64Encode(blob.getBytes())};
}
function 압축_(d) {
  제출함권한_(d.boxId,'download');const p=설정_();
  const all=목록_('파일').filter(f=>f.boxId===d.boxId&&f.status==='stored');
  const ids=Array.isArray(d.ids)?new Set(d.ids):null, fs=ids?all.filter(f=>ids.has(f.id)):all;
  if(!fs.length)throw new Error('파일을 선택하세요.');
  if(fs.length>Number(p.ZIP_COUNT)||fs.reduce((n,f)=>n+Number(f.size),0)>Number(p.ZIP_MB)*1048576)throw new Error('압축 제한을 초과했습니다. 더 적은 파일을 선택하세요.');
  const blobs=fs.map((f,i)=>DriveApp.getFileById(f.driveId).getBlob().setName(String(i+1).padStart(3,'0')+'_'+f.name));
  const name='제출파일_'+Utilities.formatDate(new Date(),'Asia/Seoul','yyyyMMdd_HHmmss')+'.zip';
  const zip=Utilities.zip(blobs,name);
  감사_('ZIP 다운로드',d.boxId+':'+fs.length+'개');
  // 응답으로 전달하므로 공개 링크나 공유 임시 파일을 만들지 않습니다.
  return {name:name,mime:'application/zip',base64:Utilities.base64Encode(zip.getBytes())};
}
function 대시보드_(d) {
  관리자_();const y=숫자_(d.year||현재학년도_(),2020,2100), receipts=목록_('접수').filter(r=>Number(r.year)===y), boxes=목록_('제출함').filter(b=>Number(b.year)===y);
  const ids=new Set(receipts.map(r=>r.id)), fs=목록_('파일').filter(f=>ids.has(f.receiptId)&&f.status==='stored'), success=new Set(fs.map(f=>f.receiptId));
  const completed=receipts.filter(r=>success.has(r.id)), users=new Set(completed.map(r=>r.studentId||[r.grade,r.classNo,r.student].join('|')));
  const daily={}, byBox={}; const cutoff=Date.now()-30*86400000;
  completed.filter(r=>Date.parse(r.createdAt)>=cutoff).forEach(r=>{const day=Utilities.formatDate(new Date(r.createdAt),'Asia/Seoul','MM-dd');daily[day]=(daily[day]||0)+1;byBox[r.boxId]=(byBox[r.boxId]||0)+1;});
  return {receipts:completed.length,files:fs.length,users:users.size,boxes:boxes.filter(b=>접수가능_(b)).length,teachers:목록_('교사').filter(t=>t.status==='approved').length,incomplete:receipts.filter(r=>['uploading','partial','failed'].includes(r.status)).length,daily:Object.keys(daily).sort().map(k=>({label:k,value:daily[k]})),byBox:Object.keys(byBox).map(k=>({label:(boxes.find(b=>b.id===k)||{}).name||'이전 제출함',value:byBox[k]})),notice:'제출자 수는 학생 ID 또는 학년·반·이름 조합 기준입니다. 통계는 선택 학년도 기준입니다.'};
}
