/** 이 두 값을 먼저 수정한 다음, 편집기에서 초기설정을 실행하세요. */
const 최초설정 = {
  관리자이메일: 'admin@school.example.kr',
  학교도메인: 'school.example.kr'
};

const 표구조 = {
  학급: ['id','year','grade','classNo','active'],
  학생: ['id','year','grade','classNo','number','name','active'],
  교사: ['id','email','name','status','createdAt'],
  인증신청: ['id','email','name','year','grade','classNo','homeroom','status','createdAt'],
  담임: ['id','year','grade','classNo','teacherId'],
  제출함: ['id','year','name','type','grade','classNo','active','sort','openAt','closeAt','folderId','deleteAt'],
  권한: ['id','boxId','teacherId','view','download','manage'],
  접수: ['id','requestId','year','grade','classNo','studentId','student','parent','phone','salt','proof','boxId','status','createdAt','updatedAt'],
  파일: ['id','receiptId','clientId','boxId','originalName','name','size','mime','driveId','status','createdAt'],
  학생폴더: ['id','boxId','studentKey','folderId'],
  감사: ['id','actor','action','target','createdAt'],
  임시파일: ['id','driveId','expireAt'],
  통계: ['id','year','date','boxId','count','files']
};

/** 익명 자동 실행 금지. 최초 관리자 본인이 편집기에서 실행합니다. */
function 초기설정() {
  const email = Session.getActiveUser().getEmail().toLowerCase();
  if (!email || email !== 최초설정.관리자이메일.trim().toLowerCase()) {
    throw new Error('설정.gs의 관리자이메일을 현재 편집기 계정으로 바꿔 주세요.');
  }
  if (email.endsWith('@school.example.kr')) throw new Error('예시 이메일을 실제 학교 이메일로 수정하세요.');
  const lock = LockService.getScriptLock(); lock.waitLock(20000);
  try {
    const p = PropertiesService.getScriptProperties();
    let db;
    if (p.getProperty('DB_ID')) db = SpreadsheetApp.openById(p.getProperty('DB_ID'));
    else { db = SpreadsheetApp.create('학교 파일 제출 DB'); p.setProperty('DB_ID', db.getId()); }
    db.setSpreadsheetTimeZone('Asia/Seoul');
    Object.keys(표구조).forEach(name => {
      const sheet = db.getSheetByName(name) || db.insertSheet(name);
      if (!sheet.getLastRow()) { sheet.appendRow(표구조[name]); sheet.setFrozenRows(1); }
    });
    if (!p.getProperty('ROOT_ID')) {
      const root = DriveApp.createFolder('학교 제출자료');
      p.setProperty('ROOT_ID', root.getId());
    }
    const root = DriveApp.getFolderById(p.getProperty('ROOT_ID'));
    if (!p.getProperty('TEMP_ID')) p.setProperty('TEMP_ID', root.createFolder('_임시파일').getId());
    if (!p.getProperty('SECRET')) p.setProperty('SECRET', Utilities.getUuid() + Utilities.getUuid());
    const defaults = {
      ADMINS: email, DOMAIN: 최초설정.학교도메인.toLowerCase(),
      FILE_MB: '8', TOTAL_MB: '24', FILE_COUNT: '10', ZIP_MB: '20', ZIP_COUNT: '40',
      RETENTION_DAYS: '365', PUBLIC_URL: '', STAFF_URL: ''
    };
    Object.keys(defaults).forEach(k => { if (p.getProperty(k) === null) p.setProperty(k, defaults[k]); });
    if (!ScriptApp.getProjectTriggers().some(t => t.getHandlerFunction() === '정기정리')) {
      ScriptApp.newTrigger('정기정리').timeBased().everyDays(1).atHour(3).create();
    }
    console.log('초기화 완료. DB: ' + db.getUrl());
    console.log('드라이브: ' + root.getUrl());
  } finally { lock.releaseLock(); }
}

function 설정_() {
  const p = PropertiesService.getScriptProperties().getProperties();
  if (!p.DB_ID) throw new Error('운영자가 먼저 초기설정을 실행해야 합니다.');
  return p;
}
function 현재학년도_() {
  const d = Utilities.formatDate(new Date(), 'Asia/Seoul', 'yyyy-MM').split('-').map(Number);
  return d[0] - (d[1] < 3 ? 1 : 0);
}
function 시각_() { return new Date().toISOString(); }
function 아이디_() { return Utilities.getUuid(); }
function 정리_(v, max) { return String(v == null ? '' : v).normalize('NFC').trim().slice(0, max || 200); }
function 숫자_(v, min, max) {
  const n = Number(v);
  if (!Number.isInteger(n) || n < min || n > max) throw new Error('숫자 범위를 확인해 주세요.');
  return n;
}
function 불리언_(v) { return v === true || String(v).toLowerCase() === 'true'; }
function 학교메일_(v) {
  const e = 정리_(v).toLowerCase();
  if (!/^[^\s@]+@[^\s@]+$/.test(e) || e.split('@')[1] !== 설정_().DOMAIN) throw new Error('학교 이메일을 입력하세요.');
  return e;
}
function 표_(name) {
  if (!표구조[name]) throw new Error('잘못된 데이터 요청입니다.');
  return SpreadsheetApp.openById(설정_().DB_ID).getSheetByName(name);
}
function 목록_(name) {
  const data = 표_(name).getDataRange().getValues();
  const keys = data.shift();
  return data.filter(r => r[0]).map(r => {
    const o = {}; keys.forEach((k,i) => o[k] = r[i] instanceof Date ? r[i].toISOString() : r[i]); return o;
  });
}
function 안전셀_(v) {
  if (typeof v === 'string' && /^[=+\-@\t\r]/.test(v)) return "'" + v;
  return v == null ? '' : v;
}
function 추가_(name, obj) { 추가여럿_(name, [obj]); }
function 추가여럿_(name, rows) {
  if (!rows.length) return;
  const s = 표_(name), keys = 표구조[name];
  s.getRange(s.getLastRow()+1,1,rows.length,keys.length).setValues(rows.map(o => keys.map(k => 안전셀_(o[k]))));
}
function 수정_(name, id, changes) {
  const s = 표_(name), data = s.getDataRange().getValues(), keys = 표구조[name];
  const idx = data.findIndex((r,i) => i > 0 && String(r[0]) === String(id));
  if (idx < 0) throw new Error('자료를 찾을 수 없습니다.');
  keys.forEach((k,i) => { if (Object.prototype.hasOwnProperty.call(changes,k)) data[idx][i] = 안전셀_(changes[k]); });
  s.getRange(idx+1,1,1,keys.length).setValues([data[idx]]);
}
function 제거_(name, id) {
  const s = 표_(name), ids = s.getRange(1,1,Math.max(1,s.getLastRow()),1).getValues();
  const i = ids.findIndex((r,j) => j > 0 && String(r[0]) === String(id));
  if (i >= 0) s.deleteRow(i+1);
}
function 잠금_(fn) {
  const lock = LockService.getScriptLock();
  if (!lock.tryLock(20000)) throw new Error('다른 요청을 처리 중입니다. 잠시 후 다시 시도하세요.');
  try { return fn(); } finally { lock.releaseLock(); }
}
function 사용자_() {
  const p = 설정_(), email = Session.getActiveUser().getEmail().toLowerCase();
  if (!email || email.split('@')[1] !== p.DOMAIN) return {role:'guest',email:''};
  if (p.ADMINS.split(',').map(x => x.trim().toLowerCase()).includes(email)) return {role:'admin',email:email,name:'관리자'};
  const t = 목록_('교사').find(t => t.email === email);
  if (t && t.status === 'approved') return {role:'teacher',email:email,name:t.name,id:t.id};
  const r = 목록_('인증신청').filter(r => r.email === email).pop();
  return {role:'unapproved',email:email,name:t ? t.name : '',status:t && t.status !== 'approved' ? t.status : (r ? r.status : 'none')};
}
function 관리자_() { const u = 사용자_(); if (u.role !== 'admin') throw new Error('관리자 권한이 필요합니다.'); return u; }
function 교직원_() { const u = 사용자_(); if (!['admin','teacher'].includes(u.role)) throw new Error('승인된 학교 계정으로 로그인하세요.'); return u; }
function 제출함권한_(boxId, kind) {
  const u = 교직원_(), b = 목록_('제출함').find(b => b.id === boxId);
  if (!b) throw new Error('제출함을 찾을 수 없습니다.');
  if (u.role === 'admin') return b;
  if (b.deleteAt) throw new Error('삭제 대기 중인 제출함입니다.');
  const a = 목록_('권한').find(a => a.boxId === boxId && a.teacherId === u.id);
  if (!a || !불리언_(a[kind || 'view'])) throw new Error('이 제출함에 대한 권한이 없습니다.');
  return b;
}
function 감사_(action,target) {
  추가_('감사',{id:아이디_(),actor:Session.getActiveUser().getEmail() || '익명',action:action,target:target,createdAt:시각_()});
}
function 서명_(text) {
  return Utilities.base64EncodeWebSafe(Utilities.computeHmacSha256Signature(text, 설정_().SECRET));
}
function 동일_(a,b) {
  a = String(a); b = String(b); let diff = a.length ^ b.length;
  for (let i=0;i<Math.max(a.length,b.length);i++) diff |= (a.charCodeAt(i)||0) ^ (b.charCodeAt(i)||0);
  return diff === 0;
}
function 캐시삭제_() { CacheService.getScriptCache().remove('public-config'); }

/** 트리거 실행 함수. 외부 호출은 관리자만 가능합니다. */
function 정기정리() {
  // 설치형 트리거는 소유자 계정으로 실행됩니다. 익명 호출은 거부합니다.
  관리자_();
  return 잠금_(() => {
    const now = Date.now(), errors = [];
    목록_('임시파일').filter(x => Date.parse(x.expireAt) <= now).forEach(x => {
      try { DriveApp.getFileById(x.driveId).setTrashed(true); 제거_('임시파일',x.id); }
      catch(e) { errors.push('임시파일 ' + x.id); }
    });
    목록_('제출함').filter(b => b.deleteAt && Date.parse(b.deleteAt) <= now).forEach(b => {
      try {
        DriveApp.getFolderById(b.folderId).setTrashed(true);
        const f = 목록_('파일').filter(f => f.boxId === b.id && f.status === 'stored');
        f.forEach(x => 수정_('파일',x.id,{status:'trashed'}));
        수정_('제출함',b.id,{deleteAt:'',active:false,name:b.name + ' [휴지통 이동]',folderId:''});
        감사_('제출함 휴지통 이동',b.id);
      } catch(e) { errors.push('제출함 ' + b.id); }
    });
    const limit = now - 86400000;
    목록_('접수').filter(r => r.status === 'uploading' && Date.parse(r.updatedAt) < limit).forEach(r => {
      const any = 목록_('파일').some(f => f.receiptId === r.id && f.status === 'stored');
      수정_('접수',r.id,{status:any ? 'partial' : 'failed',updatedAt:시각_()});
    });
    통계갱신_(); 캐시삭제_();
    if (errors.length) 감사_('정리 재시도 필요',errors.join(', '));
    return {message:errors.length ? '일부 정리에 실패했습니다. 감사 기록을 확인하세요.' : '정리가 완료되었습니다.'};
  });
}
function 통계갱신_() {
  const files = 목록_('파일').filter(f => f.status === 'stored'), receipts = 목록_('접수');
  const count = {}; files.forEach(f => count[f.receiptId] = (count[f.receiptId]||0)+1);
  const groups = {};
  receipts.filter(r => count[r.id]).forEach(r => {
    const date = Utilities.formatDate(new Date(r.createdAt),'Asia/Seoul','yyyy-MM-dd');
    const key = r.year + ':' + date + ':' + r.boxId;
    if (!groups[key]) groups[key] = {id:key,year:r.year,date:date,boxId:r.boxId,count:0,files:0};
    groups[key].count++; groups[key].files += count[r.id];
  });
  const s = 표_('통계'); if (s.getLastRow()>1) s.getRange(2,1,s.getLastRow()-1,표구조.통계.length).clearContent();
  추가여럿_('통계',Object.values(groups));
}
